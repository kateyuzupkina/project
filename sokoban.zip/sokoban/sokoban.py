import pygame
import os
import sys

pygame.init()
WIDTH = 500
HEIGHT = 500
size = WIDTH, HEIGHT
screen = pygame.display.set_mode(size)
clock = pygame.time.Clock()
level_num = 1
FPS = 50


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
            image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


def terminate():
    pygame.quit()
    sys.exit()


def start_screen():
    intro_text = ["                          СОКОБАН",
                  "            Двигайте коробки ковбоем", "",
                  "                        Управление:",
                  "                          Клавиши",
                  "       ВВЕРХ, ВНИЗ, ВЛЕВО, ВПРАВО",
                  "                   Q - выход из игры",
                  "            R - начать уровень заново",
                  "              N - следующий уровень",
                  "             B - предыдущий уровень",
                  "",
                  "     Для продолжения нажмите любую",
                  "                            клавишу"]

    fon = pygame.transform.scale(load_image('fon.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 36)
    text_coord = 10
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            keys = pygame.key.get_pressed()
            if event.type == pygame.QUIT or keys[pygame.K_q]:
                terminate()
            elif event.type == pygame.KEYDOWN:
                return
        pygame.display.flip()
        clock.tick(FPS)


def intrm_screen():
    intro_text = ["Вы прошли уровень!", "",
                  "Нажмите любую клавишу,",
                  "чтобы пройти дальше",
                  "",
                  "Нажмите Q для выхода из игры"]

    fon = pygame.transform.scale(load_image('fon.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 36)
    text_coord = 50
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 10
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            keys = pygame.key.get_pressed()
            if event.type == pygame.QUIT or keys[pygame.K_q]:
                terminate()
            elif event.type == pygame.KEYDOWN:
                return
        pygame.display.flip()
        clock.tick(FPS)


def load_level(level):
    filename = "data/levels.txt"

    with open(filename, 'r') as mapFile:
        level_map = [line.strip() for line in mapFile]
        ind = level_map.index(str(level))
        level_map = level_map[ind + 1: ind + 11]

    max_width = max(map(len, level_map))

    return list(map(lambda x: x.ljust(max_width, '.'), level_map))


class Tile(pygame.sprite.Sprite):
    def __init__(self, tile_type, pos_x, pos_y):
        super().__init__(tiles_group, all_sprites)
        self.image = tile_images[tile_type]
        self.rect = self.image.get_rect().move(tile_width * pos_x, tile_height * pos_y)
        if tile_type == 'wall':
            walls_group.add(self)
        if tile_type == 'finish':
            finish_group.add(self)


class Player(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(player_group, all_sprites)
        self.image = player_image
        self.rect = self.image.get_rect().move(tile_width * pos_x, tile_height * pos_y)


class Box(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(box_group, all_sprites)
        self.image = box_image
        self.rect = self.image.get_rect().move(tile_width * pos_x, tile_height * pos_y)


def generate_level(level):
    new_player, x, y, new_star = None, None, None, None
    for y in range(len(level)):
        for x in range(len(level[y])):
            if level[y][x] == '.':
                Tile('empty', x, y)
            elif level[y][x] == '#':
                Tile('wall', x, y)
            elif level[y][x] == '$':
                Tile('finish', x, y)
            elif level[y][x] == '*':
                Tile('empty', x, y)
                new_star = Box(x, y)
            elif level[y][x] == '@':
                Tile('empty', x, y)
                new_player = Player(x, y)
    return new_player, x, y, new_star


def clear():
    all_sprites = pygame.sprite.Group()
    tiles_group = pygame.sprite.Group()
    player_group = pygame.sprite.Group()
    star_group = pygame.sprite.Group()
    finish_group = pygame.sprite.Group()
    walls_group = pygame.sprite.Group()
    return all_sprites, tiles_group, player_group, star_group, finish_group, walls_group


tile_images = {'wall': load_image('wall.png'), 'empty': load_image('sky.png'), 'finish': load_image('place.png')}
player_image = load_image('cowboy.png')
box_image = load_image('box.png')
tile_width = tile_height = 50

player = None
star = None

all_sprites = pygame.sprite.Group()
tiles_group = pygame.sprite.Group()
player_group = pygame.sprite.Group()
box_group = pygame.sprite.Group()
finish_group = pygame.sprite.Group()
walls_group = pygame.sprite.Group()

new_player, level_x, level_y, new_box = generate_level(load_level(level_num))

start_screen()

goals = 0
box_count = len(box_group)
running = True

while running:
    clock.tick(FPS)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        for box in box_group:
            if pygame.sprite.spritecollideany(box, finish_group, False):
                goals += 1
        if goals == box_count:
            intrm_screen()
            all_sprites, tiles_group, player_group, box_group, finish_group, walls_group = clear()
            level_num += 1
            if level_num > 10:
                level_num = 1
            new_player, level_x, level_y, new_box = generate_level(load_level(level_num))
            box_count = len(box_group)
        goals = 0
        keys = pygame.key.get_pressed()
        if keys[pygame.K_n]:
            level_num += 1
            if level_num > 10:
                level_num = 1
            all_sprites, tiles_group, player_group, box_group, finish_group, walls_group = clear()
            new_player, level_x, level_y, new_box = generate_level(load_level(level_num))
            box_count = len(box_group)
        elif keys[pygame.K_b]:
            level_num -= 1
            if level_num < 1:
                level_num = 10
            all_sprites, tiles_group, player_group, box_group, finish_group, walls_group = clear()
            new_player, level_x, level_y, new_box = generate_level(load_level(level_num))
            box_count = len(box_group)
        elif keys[pygame.K_q]:
            terminate()
        elif keys[pygame.K_r]:
            all_sprites, tiles_group, player_group, box_group, finish_group, walls_group = clear()
            new_player, level_x, level_y, new_box = generate_level(load_level(level_num))
            box_count = len(box_group)
        elif keys[pygame.K_LEFT]:
            new_player.rect.x -= 50
            if not pygame.sprite.spritecollideany(new_player, walls_group, False):
                if pygame.sprite.spritecollideany(new_player, box_group, False):
                    new_player.rect.x -= 50
                    if not pygame.sprite.spritecollideany(new_player, box_group, False):
                        new_player.rect.x += 50
                        boxes = pygame.sprite.spritecollide(new_player, box_group, False)
                        for box in boxes:
                            box.rect.x -= 50
                            if pygame.sprite.spritecollideany(box, walls_group):
                                box.rect.x += 50
                        new_player.rect.x -= 50
                        if new_player.rect.x == 0 or pygame.sprite.spritecollideany(new_player, walls_group, False):
                            new_player.rect.x += 50
                        new_player.rect.x += 50
                    else:
                        new_player.rect.x += 100
            else:
                new_player.rect.x += 50
        elif keys[pygame.K_RIGHT]:
            new_player.rect.x += 50
            if not pygame.sprite.spritecollideany(new_player, walls_group, False):
                if pygame.sprite.spritecollideany(new_player, box_group, False):
                    new_player.rect.x += 50
                    if not pygame.sprite.spritecollideany(new_player, box_group, False):
                        new_player.rect.x -= 50
                        boxes = pygame.sprite.spritecollide(new_player, box_group, False)
                        for box in boxes:
                            box.rect.x += 50
                            if pygame.sprite.spritecollideany(box, walls_group):
                                box.rect.x -= 50
                        new_player.rect.x += 50
                        if new_player.rect.x == 500 or pygame.sprite.spritecollideany(new_player, walls_group, False):
                            new_player.rect.x -= 50
                        new_player.rect.x -= 50
                    else:
                        new_player.rect.x -= 100
            else:
                new_player.rect.x -= 50
        elif keys[pygame.K_UP]:
            new_player.rect.y -= 50
            if not pygame.sprite.spritecollideany(new_player, walls_group, False):
                if pygame.sprite.spritecollideany(new_player, box_group, False):
                    new_player.rect.y -= 50
                    if not pygame.sprite.spritecollideany(new_player, box_group, False):
                        new_player.rect.y += 50
                        boxes = pygame.sprite.spritecollide(new_player, box_group, False)
                        for box in boxes:
                            box.rect.y -= 50
                            if pygame.sprite.spritecollideany(box, walls_group):
                                box.rect.y += 50
                        new_player.rect.y -= 50
                        if new_player.rect.y == 0 or pygame.sprite.spritecollideany(new_player, walls_group, False):
                            new_player.rect.y += 50
                        new_player.rect.y += 50
                    else:
                        new_player.rect.y += 100
            else:
                new_player.rect.y += 50
        elif keys[pygame.K_DOWN]:
            new_player.rect.y += 50
            if not pygame.sprite.spritecollideany(new_player, walls_group, False):
                if pygame.sprite.spritecollideany(new_player, box_group, False):
                    new_player.rect.y += 50
                    if not pygame.sprite.spritecollideany(new_player, box_group, False):
                        new_player.rect.y -= 50
                        boxes = pygame.sprite.spritecollide(new_player, box_group, False)
                        for box in boxes:
                            box.rect.y += 50
                            if pygame.sprite.spritecollideany(box, walls_group):
                                box.rect.y -= 50
                        new_player.rect.y += 50
                        if new_player.rect.y == 500 or pygame.sprite.spritecollideany(new_player, walls_group, False):
                            new_player.rect.y -= 50
                        new_player.rect.y -= 50
                    else:
                        new_player.rect.y -= 100
            else:
                new_player.rect.y -= 50
        if new_player.rect.right > WIDTH:
            new_player.rect.right = WIDTH
        if new_player.rect.top < 0:
            new_player.rect.top = 0
        if new_player.rect.left < 0:
            new_player.rect.left = 0
        if new_player.rect.bottom > HEIGHT:
            new_player.rect.bottom = HEIGHT

    all_sprites.update()
    tiles_group.update()
    box_group.update()
    player_group.update()

    all_sprites.draw(screen)
    tiles_group.draw(screen)
    box_group.draw(screen)
    player_group.draw(screen)

    pygame.display.flip()

pygame.quit()
